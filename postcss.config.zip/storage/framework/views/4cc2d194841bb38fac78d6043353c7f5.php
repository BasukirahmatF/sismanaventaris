<?php if (isset($component)) { $__componentOriginal4e7e7d2ea929ed96c9d12470ca03fcf2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4e7e7d2ea929ed96c9d12470ca03fcf2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('auth'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> <?php echo e($title); ?> <?php $__env->endSlot(); ?>
    <form method="POST" action="<?php echo e(route('login.post')); ?>" class="w-full">
        <?php echo csrf_field(); ?>
        <h1 class="mb-4 text-md text-center font-semibold text-gray-700 dark:text-gray-200">
            Masuk Akun
        </h1>
        <label class="block text-sm">
            <span class="text-gray-700 dark:text-gray-400">Username</span>
            <input name="username" required class="block w-full mt-1 text-sm form-input" placeholder="Masukkan Username" />
        </label>
        <label class="block mt-4 text-sm">
            <span class="text-gray-700 dark:text-gray-400">Password</span>
            <input name="password" required class="block w-full mt-1 text-sm form-input" placeholder="Masukkan Password" type="password" />
        </label>

        <button type="submit" class="block w-full px-4 py-2 mt-4 text-sm font-medium leading-5 text-center text-white transition-colors duration-150 bg-blue-600 border border-transparent rounded-lg">
            Login
        </button>
    </form>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4e7e7d2ea929ed96c9d12470ca03fcf2)): ?>
<?php $attributes = $__attributesOriginal4e7e7d2ea929ed96c9d12470ca03fcf2; ?>
<?php unset($__attributesOriginal4e7e7d2ea929ed96c9d12470ca03fcf2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4e7e7d2ea929ed96c9d12470ca03fcf2)): ?>
<?php $component = $__componentOriginal4e7e7d2ea929ed96c9d12470ca03fcf2; ?>
<?php unset($__componentOriginal4e7e7d2ea929ed96c9d12470ca03fcf2); ?>
<?php endif; ?><?php /**PATH C:\Users\ASUS\Downloads\manajemen_inventaris\resources\views/auth/signin.blade.php ENDPATH**/ ?>