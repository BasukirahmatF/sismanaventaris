<?php

namespace App\Http\Controllers;

use App\Models\Supplier;
use App\Models\Item;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class DashboardController extends Controller {
    public function __construct() {
        if (!Auth::check()) {
            return redirect()->route('login');
        }
    }
    public function index() {
        return view('index', [
            'title' => 'Dashboard',
            'totalSuppliers' => Supplier::count(),
            'totalItems' => Item::count()
        ]);
    }
}
